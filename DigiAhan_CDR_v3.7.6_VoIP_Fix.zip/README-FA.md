﻿# دیجی‌آهن CDR نسخه ۳.۷.۶

این نسخه فقط خطای نهایی `VoIP event API: 500` را اصلاح می‌کند و به اتصال حسابداری، داده‌های دیدار، Mappingها و Task همگام‌سازی نسخه ۳.۷.۵ دست نمی‌زند.

## علت فنی

در Agent Panel چند درخواست هم‌زمان می‌توانستند تابع `EnsureSchema` را اجرا کنند. هر دو درخواست نبودن جدول را می‌دیدند و سپس هم‌زمان برای ساخت `AgentIncomingEvents` اقدام می‌کردند. نتیجه یکی از درخواست‌ها خطای SQL شماره 2714 بود:

```text
There is already an object named 'AgentIncomingEvents' in the database.
```

از آنجا که ذخیره History قبل از پاسخ VoIP انجام می‌شد، همین خطای فرعی کل `/api/voip/events` را با HTTP 500 متوقف می‌کرد.

## اصلاحات v3.7.6

- قفل داخل برنامه با `SemaphoreSlim`
- قفل بین پردازش‌ها با `sp_getapplock`
- Migration خودکار ستون‌ها و Indexهای Agent Panel
- تعیین صریح Precision و Scale برای مبالغ
- انتشار Popup داخلی قبل از ذخیره History
- در صورت خطای ذخیره History، Popup همچنان با HTTP 200 ارسال می‌شود
- ثبت مرحله دقیق خطا در لاگ
- بررسی Schema در زمان Start برنامه
- بدون Import دوباره حسابداری

## نصب

محتویات ZIP را مستقیم داخل مسیر زیر Extract کنید:

```text
D:\DigiAhan\CDR3.1.0git
```

سپس:

```powershell
cd D:\DigiAhan\CDR3.1.0git
.\RUN-v3.7.6.cmd
```

## خروجی نهایی مورد انتظار

```text
Summary: PASS=12 WARN/SKIP=0 FAIL=0
Diagnostics: ALL PASS
```

و این تست باید PASS شود:

```text
VoIP → Identity → Accounting
Name=فتح‌الله کرمی
Code=30/000010
```

## تست واقعی Issabel

```bash
digiahan-test-ring 201 09121395663
```

پنل:

```text
http://192.168.8.143:5088/agent/201
```

## راه‌اندازی مستقل داشبورد

```powershell
.\START-DASHBOARD-NOW-v3.7.6.cmd
```

## بازگشت

```powershell
.\ROLLBACK-v3.7.6.cmd
```

## گزارش‌ها

```text
D:\DigiAhan\CDR3.1.0git\Logs\MVP-v3.7.6-*.txt
D:\DigiAhan\CDR3.1.0git\Logs\v3.7.6-app-output.log
D:\DigiAhan\CDR3.1.0git\Logs\v3.7.6-app-error.log
```
