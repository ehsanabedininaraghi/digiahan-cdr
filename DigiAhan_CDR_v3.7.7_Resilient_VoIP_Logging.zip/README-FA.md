﻿# دیجی‌آهن CDR نسخه ۳.۷.۷

این نسخه دو هدف دارد:

1. حذف خطای فعلی `VoIP event API: 500`
2. ساخت یک فایل ZIP تشخیصی کامل بعد از **هر اجرا**، چه موفق و چه ناموفق

## تغییر اصلی VoIP

در نسخه‌های قبل اگر ساخت کارت کامل مشتری به هر دلیل شکست می‌خورد، کل API پاسخ 500 می‌داد.

در ۳.۷.۷:

- ساخت کارت کامل حداکثر ۸ ثانیه فرصت دارد.
- اگر خطا، Timeout یا Deadlock رخ دهد، سیستم خودکار وارد حالت `FALLBACK` می‌شود.
- اطلاعات پایه از `CustomerPhoneDirectory` خوانده می‌شود.
- Popup داخلی همچنان ارسال می‌شود.
- ذخیره History دیگر نمی‌تواند Popup را متوقف کند.
- نوع پاسخ در Header مشخص است:
  - `X-Voip-Mode: FULL`
  - `X-Voip-Mode: FALLBACK`

برای شماره آزمایشی فتح‌الله کرمی، حتی در حالت Fallback باید کد `30/000010` از دفترچه یکپارچه مشتریان برگردد.

## لاگ کامل هر اجرا

هر بار که `RUN-v3.7.7.cmd` اجرا شود، یک پوشه و یک ZIP می‌سازد:

```text
D:\DigiAhan\CDR3.1.0git\Logs\Runs\v3.7.7-YYYYMMDD-HHMMSS\
D:\DigiAhan\CDR3.1.0git\Logs\Runs\v3.7.7-YYYYMMDD-HHMMSS.zip
```

داخل ZIP این موارد قرار می‌گیرند:

- `installer-transcript.txt`
- `installer-summary.txt`
- `diagnostics-console.txt`
- `fatal-error.txt` در صورت خطا
- `application-stdout.log`
- `application-stderr.log`
- `recent-application-logs.txt`
- `environment.txt`
- `config-sanitized.txt`
- `scheduled-tasks.txt`
- `ports-and-processes.txt`
- `git-status.txt`
- گزارش‌های تست TXT و JSON

رمزها و Tokenها در فایل تنظیمات Sanitized مخفی می‌شوند.

## نصب

محتویات ZIP را مستقیم در این مسیر Extract کنید:

```text
D:\DigiAhan\CDR3.1.0git
```

سپس:

```powershell
cd D:\DigiAhan\CDR3.1.0git
.\RUN-v3.7.7.cmd
```

این نسخه حسابداری را دوباره Import نمی‌کند.

## نتیجه مطلوب

```text
[PASS] VoIP → Identity → Accounting
Summary: PASS=12 WARN/SKIP=0 FAIL=0
```

## اگر هنوز خطایی ماند

فقط آخرین فایل زیر را ارسال کنید:

```text
D:\DigiAhan\CDR3.1.0git\Logs\Runs\v3.7.7-*.zip
```

دیگر لازم نیست دستی دنبال app.log، RequestId یا Stack Trace بگردید. بالاخره سیستم خودش گزارش می‌دهد کجایش شکسته، چون ظاهراً اعتراف گرفتن از نرم‌افزار هم نیاز به بازجویی ساختاریافته دارد.

## اجرای مستقل داشبورد

```powershell
.\START-DASHBOARD-NOW-v3.7.7.cmd
```

## Rollback

```powershell
.\ROLLBACK-v3.7.7.cmd
```
