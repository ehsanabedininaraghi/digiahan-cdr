﻿# DigiAhan CDR v3.7.5 Hotfix

این بسته برای خروجی واقعی اجرای v3.7.4 ساخته شده است.

## علت خطای اصلی

`SqlBulkCopy` نتوانسته جدول موقت محلی زیر را ببیند:

```text
#AccountingVisitorsStage
```

در نتیجه Sync قبل از ورود فاکتورهای جدید و اجرای Identity Builder متوقف شده است.

## اصلاحات

- جایگزینی `#temp table` با جدول Staging یکتای واقعی داخل همان Transaction
- حذف خودکار جدول‌های Staging پیش از Commit
- ورود مجدد مشتریان، فروشندگان، فاکتورها و اقلام
- اجرای Identity Builder بعد از Sync موفق
- اصلاح Aliasهای API وضعیت حسابداری
- اصلاح تست `lastSyncStatus` و `invoiceCount`
- ثبت متن کامل خطای HTTP 500 در تست VoIP
- حذف Taskهای قدیمی v3.7.2 و v3.7.4
- ساخت Task صحیح v3.7.5 هر ۱۵ دقیقه
- Backup و Rollback
- راه‌اندازی مجدد داشبورد حتی در صورت شکست Sync

## نصب

محتویات ZIP را مستقیماً داخل مسیر زیر Extract کنید:

```text
D:\DigiAhan\CDR3.1.0git
```

سپس:

```powershell
cd D:\DigiAhan\CDR3.1.0git
.\RUN-v3.7.5.cmd
```

## خروجی مورد انتظار

```text
Accounting Bridge v3.7.5
Legacy SQL connected. Login=sa Database=daftar1405
Read: Customers=1435, Visitors=8, Invoices=..., Items=...
Accounting synchronization completed successfully against the real schema and persistent staging tables.
Identity rebuild completed.
```

در Diagnostics باید این موارد PASS شوند:

```text
Accounting SQL2000
DigiAhan_CDR SQL
Accounting import
Didar CRM data
Issabel CDR data
Mapping: فتح‌الله کرمی
Mapping: محمد کثیری
Mapping: یاراو مصطفی
Receiver application
Accounting status API
Sales dashboard API
VoIP → Identity → Accounting
```

## بالا آوردن مستقل داشبورد

اگر هر مرحله‌ای متوقف شد:

```powershell
.\START-DASHBOARD-NOW-v3.7.5.cmd
```

## Rollback

```powershell
.\ROLLBACK-v3.7.5.cmd
```

## تست واقعی Issabel

```bash
digiahan-test-ring 201 09121395663
```

سپس:

```text
http://192.168.8.143:5088/agent/201
```

## گزارش

```text
D:\DigiAhan\CDR3.1.0git\Logs\MVP-v3.7.5-*.txt
D:\DigiAhan\CDR3.1.0git\Logs\MVP-v3.7.5-*.json
D:\DigiAhan\CDR3.1.0git\Logs\v3.7.5-app-error.log
```
