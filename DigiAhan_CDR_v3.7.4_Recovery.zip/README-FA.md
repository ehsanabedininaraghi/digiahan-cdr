﻿# دیجی‌آهن CDR نسخه ۳.۷.۴

این نسخه از روی **کل سورس واقعی ارسالی** و دو خروجی واقعی Schema دیتابیس ساخته شده است.

هدف نسخه ۳.۷.۴ اول از همه این است که داشبورد دوباره بالا بیاید و بعد اتصال حسابداری، دیدار، Issabel و SQL Server با Schema واقعی بررسی شود. فعلاً از نوشتن «نسخه نهایی جهان» خودداری کرده‌ایم؛ چون نرم‌افزار هم مثل ساختمان است و با چسب نواری ضدزلزله نمی‌شود.

## اصلاحات اصلی

- استفاده از ستون واقعی `AccountingSyncRuns.CutoffPersianDate`
- حذف استفاده اشتباه از `CutoffDate`
- استفاده مستقیم از ADODB و Login واقعی `sa`
- استفاده از ستون واقعی `DidarContactPhones.OriginalPhone`
- شناسایی هر دو شکل کد حسابداری:
  - `30/000010`
  - `000010`
- اجرای Schema حسابداری قبل از Import
- ساخت یا تکمیل ستون لازم در صورت نبودن
- شروع داشبورد **قبل از Sync حسابداری**
- ادامه کار داشبورد حتی اگر Import حسابداری خطا بدهد
- Backup کامل قبل از نصب
- Rollback آماده
- Task همگام‌سازی هر ۱۵ دقیقه
- گزارش اتصال حسابداری، دیدار، Issabel، CDR و پنل داخلی
- نسخه برنامه و Cache فایل‌های داشبورد روی `3.7.4`

## نصب

فایل ZIP را باز کنید و **تمام محتویات داخل آن** را مستقیماً در این مسیر Extract کنید:

```text
D:\DigiAhan\CDR3.1.0git
```

سپس PowerShell را باز کنید:

```powershell
cd D:\DigiAhan\CDR3.1.0git
.\RUN-v3.7.4.cmd
```

نسخه مستقیم:

```powershell
powershell -ExecutionPolicy Bypass -File .\RUN-v3.7.4.ps1
```

## فقط بالا آوردن فوری داشبورد

اگر نصب در مرحله Sync یا Task متوقف شد، داشبورد را مستقل بالا بیاورید:

```powershell
cd D:\DigiAhan\CDR3.1.0git
.\START-DASHBOARD-NOW-v3.7.4.cmd
```

این فایل هیچ Importی انجام نمی‌دهد و فقط Build و اجرای داشبورد را انجام می‌دهد.

## آدرس‌ها

```text
http://192.168.8.143:5088/dashboard
http://192.168.8.143:5088/agent/201
http://192.168.8.143:5088/health
```

## خروجی موفق حسابداری

```text
Legacy SQL connected. Login=sa Database=daftar1405
Accounting synchronization completed successfully against the real schema.
Identity rebuild completed.
```

## تست نهایی Issabel

پس از اجرای نسخه:

```bash
digiahan-test-ring 201 09121395663
```

صفحه داخلی ۲۰۱ باید اطلاعات فتح‌الله کرمی و کد حسابداری را نشان دهد.

## گزارش‌ها

```text
D:\DigiAhan\CDR3.1.0git\Logs\MVP-v3.7.4-*.txt
D:\DigiAhan\CDR3.1.0git\Logs\MVP-v3.7.4-*.json
D:\DigiAhan\CDR3.1.0git\Logs\v3.7.4-app-output.log
D:\DigiAhan\CDR3.1.0git\Logs\v3.7.4-app-error.log
```

## بازگشت به نسخه قبل

```powershell
.\ROLLBACK-v3.7.4.cmd
```

## نکته فنی

فایل‌های تنظیمات محلی و Tokenهای سیستم در بسته قرار نگرفته‌اند. Installer تنظیمات موجود روی سیستم را نگه می‌دارد و فقط Connection حسابداری را به شکل درست زیر اصلاح می‌کند:

```text
Provider=SQLOLEDB;Data Source=corei5;Initial Catalog=daftar1405;User ID=sa;Password=;
```

این بسته در محیط لینوکسی تولید و از نظر ساختار، ZIP، ارجاعات Schema و تعادل کدها بررسی شده است؛ اجرای نهایی روی SQL Server و ویندوز واقعی دیجی‌آهن با گزارش داخلی خود بسته سنجیده می‌شود.
